<template>
    <router-view/>
</template>
<style lang="scss" scoped>
   *{
     padding: 0;
     margin: 0;
   }
</style>