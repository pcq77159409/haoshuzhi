<template>
    <div>
        <div class="service">
            <p>收藏</p>
        </div>
        <div class="Collection" align="center">
           <img src="../assets/收藏.png" alt="" >
           <p>您暂时还没有添加收藏呢,快去选择心仪的收藏吧~</p>
        </div>
       <div class="gos">
            <div class="go">
            <p>去收藏~</p>
        </div>
       
       </div>
       
    </div>
</template>

<style scoped>
.service{
    width: 100%;
    height: 65px;
    background: #FF5757;
}
.service p{
    font-size: 16pt;
    color: white;
    font-family: PingFang-SC-Medium;
    font-weight: Medium;
    line-height: 65px;
    text-align: center;

}
.Collection{
    width: 100%;
    height: 300px;
}
.Collection img{
    width: 180pt;
    height: 115pt;
    margin-top: 50px;
}
.Collection p{
    font-size: 13px;
    margin-top: 10px;
    color: #999999;
}
.gos{
    width: 100%;
    height: 30px;
  
}
.go {
    width:280px ;
    height: 30px;
    background: #FF5757;
    border-radius: 15px;
    text-align: center;
    line-height: 30px;
    margin: 0 auto;
    color: white;
}
</style>