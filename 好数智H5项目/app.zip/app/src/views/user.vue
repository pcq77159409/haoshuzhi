<template>
  <div class="home">
 222222222
 
  </div>
</template>

<script>
// @ is an alias to /src


export default {
  components: {

  }
}
</script>
